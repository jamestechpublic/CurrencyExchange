﻿namespace CurrencyExchangeAPI.Models
{
    public class ExchangeRate
    {
        public string Currency { get; set; } = string.Empty;
        public decimal Rate { get; set; }
        public string LastUpdate { get; set; } = string.Empty;
    }
}
