﻿namespace CurrencyExchangeAPI.Models
{
    public class ConvertToModel
    {
        public static List<ExchangeRate>? ExchangeRateList(IEnumerable<dynamic> data)
        {
            try
            {
                var result = new List<ExchangeRate>();

                foreach (dynamic d in data)
                {
                    var p = ExchangeRate(d);
                    result.Add(p);
                }

                return result;
            }
            catch { return null; }
        }

        public static ExchangeRate? ExchangeRate(dynamic data)
        {
            try
            {
                var p = new ExchangeRate();

                p.Currency = data.Currency.ToString();
                p.Rate = Convert.ToDecimal(data.Rate);
                p.LastUpdate = data.LastUpdate.ToString();

                return p;
            }
            catch { return null; }
        }

        /// <summary>
        ///     Deserialize the JSON returned from the exchange service
        /// </summary>
        /// <param name="json">A JSON string</param>
        /// <returns>A list of <see cref="ExchangeRate"/></returns>
        public static List<ExchangeRate>? JsonExchaneToList(string json)
        {
            try
            {
                var result = new List<ExchangeRate>();

                json = json.Substring(9, json.Length - 11);
                var jsonSplit = json.Split(',');
                foreach (var pair in jsonSplit)
                {
                    var split = pair.Split(':');
                    string currency = split[0];
                    currency = currency.Substring(1, currency.Length - 2);
                    decimal rate = Convert.ToDecimal(split[1]);

                    var exchangeRate = new ExchangeRate();
                    exchangeRate.Currency = currency;
                    exchangeRate.Rate = rate;
                    exchangeRate.LastUpdate = DateTime.Now.ToString("yyyyMMdd_HHmm");

                    result.Add(exchangeRate);
                }

                return result;
            }
            catch { return null; }
        }
    }
}
