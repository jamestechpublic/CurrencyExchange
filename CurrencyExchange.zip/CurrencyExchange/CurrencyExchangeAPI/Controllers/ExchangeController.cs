﻿using CurrencyExchangeAPI.Services;
using Microsoft.AspNetCore.Mvc;

namespace CurrencyExchangeAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ExchangeController : ControllerBase
    {
        private readonly IExchangeService _service;

        public ExchangeController(IExchangeService service)
        {
            _service = service;
        }

        [HttpGet("convert")]
        public async Task<IActionResult> ConvertCurrencyAsync([FromQuery(Name = "base")] string baseCurrency, [FromQuery] string target, [FromQuery] string amount)
        {
            if (ModelState.IsValid)
            {
                var result = await _service.ConvertCurrencyAsync(baseCurrency, target, amount);
                return Ok(result);
            }
            else return BadRequest("Usage: /convert?base=USD&target=EUR&amount=100\n" + ModelState);
        }

        [HttpGet("GetHistoryAsync")]
        public async Task<IActionResult> GetHistoryAsync()
        {
            try
            {
                var result = await _service.GetHistoryAsync();
                return Ok(result);
            }
            catch (Exception ex) { return BadRequest(ex.Message); }
        }

        //[HttpGet("GetExchangeRatesAsync")]
        //public async Task<IActionResult> GetExchangeRatesAsync()
        //{
        //    try
        //    {
        //        var result = await _service.GetExchangeRatesAsync();
        //        return Ok(result);
        //    }
        //    catch (Exception ex) { return BadRequest(ex.Message); }
        //}

        //[HttpGet("CallPublicApiAsync")]
        //public async Task<IActionResult> CallPublicApiAsync()
        //{
        //    try
        //    {
        //        var result = await _service.CallPublicApiAsync();
        //        return Ok(result);
        //    }
        //    catch (Exception ex) { return BadRequest(ex.Message); }
        //}

    }
}
