﻿using CurrencyExchangeAPI.DataAccess;
using CurrencyExchangeAPI.Extensions;
using CurrencyExchangeAPI.Models;
using Dapper;
using Microsoft.Extensions.Caching.Distributed;
using System.Data;
using System.Net.Http.Headers;

namespace CurrencyExchangeAPI.Services
{
    public class ExchangeService : IExchangeService
    {
        private readonly IDataAccessMySQL _db;
        private readonly IDistributedCache _cache;

        public ExchangeService(IDataAccessMySQL db, IDistributedCache cache) 
        {  
            _db = db; 
            _cache = cache;
        }

        /// <summary>
        ///     Convert currency to another currency
        /// </summary>
        /// <param name="baseCurrency">The base currency, ie. USD</param>
        /// <param name="targetCurrency">The target currency, ie. ZAR</param>
        /// <param name="amount">The amount to convert, ie. 100</param>
        /// <returns>The converted amount, or a messsage if either base or target currency is not available</returns>
        /// <remarks>USD rate = 1 by default</remarks>
        public async Task<string> ConvertCurrencyAsync(string baseCurrency, string targetCurrency, string amount)
        {
            try
            {
                var rates = await GetExchangeRatesAsync();

                baseCurrency = baseCurrency.ToUpper();
                targetCurrency = targetCurrency.ToUpper();
                if (decimal.TryParse(amount, out decimal amnt) == false) return "ERROR: Specified amount is not valid.";

                // search for the exchange rates
                decimal baseRate = 1m;
                decimal targetRate = 1m;
                int found = 0;
                foreach (var rate in rates)
                {
                    if (rate.Currency == baseCurrency)
                    {
                        found++;
                        baseRate = rate.Rate;
                    }
                    if (rate.Currency == targetCurrency)
                    {
                        found++;
                        targetRate = rate.Rate;
                    }
                    if (found == 2) break;
                }

                if (found != 2) return "ERROR: Specified base or target currency not available.";

                decimal k = 1 / baseRate;  // normalize base rate to 1
                targetRate *= k;  // scale target rate to base
                decimal result = amnt * targetRate;

                return result.ToString();

            }
            catch { throw; }
        }

        /// <summary>
        ///     Get exchange rates from the Redis cache
        ///     if not available, get it from the public API
        ///     then update the cache with 15 minute record key
        ///     and update the history in MySQL
        /// </summary>
        /// <returns>A list of <see cref="ExchangeRate"/></returns>
        public async Task<List<ExchangeRate>> GetExchangeRatesAsync()
        {
            try
            {
                // make 15 minute key
                var datenow = DateTime.Now;
                int min = datenow.Minute;
                min /= 15;
                string recordKey = "exchangerates_" + datenow.ToString("yyyyMMdd_HH") + min.ToString();

                // get from cache
                var result = await _cache.GetRecordAsync<List<ExchangeRate>>(recordKey);

                if (result is null)
                {
                    // get from public API & update history
                    result = await CallPublicApiAsync();
                    // update cache
                    if (result != null)
                        await _cache.SetRecordAsync<List<ExchangeRate>>(recordKey, result, TimeSpan.FromMinutes(15));
                }

                return result ?? new List<ExchangeRate>();
            }
            catch { throw; }
        }

        /// <summary>
        ///     Call exchange service API to return latest exchange rates.
        ///     If successful, save latest to history
        /// </summary>
        /// <returns>A list of <see cref="ExchangeRate"/></returns>
        public async Task<List<ExchangeRate>> CallPublicApiAsync()
        {
            try
            {
                var result = new List<ExchangeRate>();

                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri("https://api.freecurrencyapi.com/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                string qry = "v1/latest?apikey=fca_live_8yCAXG0RLiGkyt3KaMGchoLscTgNbW4u7dk4dPTp";
                HttpResponseMessage response = await client.GetAsync(qry);

                if (response.IsSuccessStatusCode)
                {
                    string json = await response.Content.ReadAsStringAsync();
                    result = ConvertToModel.JsonExchaneToList(json);
                    if (result != null && result.Count > 0) await SaveHistoryAsync(result);
                }

                // testing......
                //string json = "{\"data\":{\"AUD\":1.4997601872,\"BGN\":1.7974403345,\"BRL\":5.1139508216,\"CAD\":1.3642002059,\"CHF\":0.9108701497,\"CNY\":7.2351713016,\"CZK\":22.7693324205,\"DKK\":6.8724909493,\"EUR\":0.9208600977,\"GBP\":0.7867201314,\"HKD\":7.8032409042,\"HRK\":6.6599710029,\"HUF\":354.9138953995,\"IDR\":15971.601550524,\"ILS\":3.6745305274,\"INR\":83.2798496127,\"ISK\":138.3030625304,\"JPY\":156.2560244667,\"KRW\":1361.3958372835,\"MXN\":16.6148222254,\"MYR\":4.6909105553,\"NOK\":10.6626519733,\"NZD\":1.6410102921,\"PHP\":58.2034606833,\"PLN\":3.9156005509,\"RON\":4.5810905467,\"RUB\":90.2942407731,\"SEK\":10.6911317838,\"SGD\":1.3470102572,\"THB\":36.3960351192,\"TRY\":32.1708855036,\"USD\":1,\"ZAR\":18.0606624649}}";
                //result = ConvertToModel.JsonExchaneToList(json);
                //if (result.Count > 0) await SaveHistoryAsync(result);

                return result ?? new List<ExchangeRate>();
            }
            catch { throw; }
        }

        #region Read History

        /// <summary>
        ///     Read all currency exchange rates history for a date
        /// </summary>
        /// <returns>A list of <see cref="ExchangeRate"/></returns>
        public async Task<List<ExchangeRate>> GetHistoryAsync()
        {
            try
            {
                string sql = "SELECT * FROM exchangerate";
                var param = new DynamicParameters();
                
                var qry = await _db.GetRecordsAsync(sql, null);
                var result = ConvertToModel.ExchangeRateList(qry);

                return result ?? new List<ExchangeRate>();
            }
            catch { throw; }
        }

        /// <summary>
        ///     Read the exchange rate history for a base and date
        /// </summary>
        /// <param name="currency">USD, ZAR, etc.</param>
        /// <returns>An <see cref="ExchangeRate"/></returns>
        public async Task<ExchangeRate> GetCurrencyHistoryAsync(string currency)
        {
            try
            {
                string sql = "SELECT * FROM exchangerate WHERE Currency = @currency";
                var param = new DynamicParameters();
                param.Add("@currency", value: currency, dbType: DbType.String);

                var qry = await _db.GetOneRecordAsync(sql, param);
                var result = ConvertToModel.ExchangeRate(qry);

                return result;
            }
            catch { throw; }
        }

        #endregion

        #region Create / Update History

        /// <summary>
        ///     Insert / update a list of exxchange rates
        /// </summary>
        /// <param name="rates">A list of <see cref="ExchangeRate"/></param>
        public async Task SaveHistoryAsync(List<ExchangeRate> rates)
        {
            try
            {
                foreach (ExchangeRate rate in rates)
                {
                    await SaveCurrencyHistoryAsync(rate);
                }
            }
            catch { throw; }
        }

        /// <summary>
        ///     Insert / update a currency exchange rate
        /// </summary>
        /// <param name="rate">A <see cref="ExchangeRate"/></param>
        public async Task SaveCurrencyHistoryAsync(ExchangeRate rate)
        {
            try
            {
                string sql = string.Empty;

                var result = await GetCurrencyHistoryAsync(rate.Currency);
                if (result != null)
                {
                    sql = "UPDATE exchangerate SET Rate = @rate, LastUpdate = @lastupdate WHERE Currency = @currency";
                }
                else
                {
                    sql = "INSERT INTO exchangerate (Currency, Rate, LastUpdate) VALUES (@currency, @rate, @lastupdate)";
                }
                var param = new DynamicParameters();
                param.Add("@currency", value: rate.Currency, dbType: DbType.String);
                param.Add("@rate", value: rate.Rate, dbType: DbType.Decimal);
                param.Add("@lastupdate", value: rate.LastUpdate, dbType: DbType.String);

                await _db.ExecuteNonQueryAsync(sql, param);
            }
            catch { throw; }
        }

        #endregion

        #region Delete History

        /// <summary>
        ///     Delete all exchange rates for a date
        /// </summary>
        /// <param name="currency">USD, ZAR, etc.</param>
        public async Task DeleteHistoryAsync()
        {
            try
            {
                string sql = "DELETE FROM exchangerate";

                await _db.ExecuteNonQueryAsync(sql, null);
            }
            catch { throw; }
        }

        #endregion

    }
}
