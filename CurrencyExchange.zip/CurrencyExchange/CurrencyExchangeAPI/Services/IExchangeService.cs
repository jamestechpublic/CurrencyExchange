﻿using CurrencyExchangeAPI.Models;

namespace CurrencyExchangeAPI.Services
{
    public interface IExchangeService
    {
        Task<string> ConvertCurrencyAsync(string baseCurrency, string targetCurrency, string amount);
        Task<List<ExchangeRate>> GetExchangeRatesAsync();
        Task<List<ExchangeRate>> CallPublicApiAsync();

        #region History CRUD

        Task<List<ExchangeRate>> GetHistoryAsync();
        Task<ExchangeRate> GetCurrencyHistoryAsync(string currency);
        Task SaveHistoryAsync(List<ExchangeRate> rates);
        Task SaveCurrencyHistoryAsync(ExchangeRate rate);
        Task DeleteHistoryAsync();

        #endregion

    }
}
