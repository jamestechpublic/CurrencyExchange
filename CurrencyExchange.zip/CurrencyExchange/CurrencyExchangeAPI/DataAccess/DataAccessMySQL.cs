﻿using Dapper;
using Microsoft.Extensions.Configuration;
using MySqlConnector;
using System.Reflection;

namespace CurrencyExchangeAPI.DataAccess
{
    /// <summary>
    ///     Generic MySQL Data Access by James Lombard May 2022
    /// </summary>
    /// <remarks>
    ///     MySqlConnector 2.3.7
    ///     Dapper 2.1.35
    /// </remarks>
    public class DataAccessMySQL : IDataAccessMySQL
    {

        string _connectionString = string.Empty;

        /// <summary>
        ///     Contructor
        /// </summary>
        /// <param name="connectionString">Connection string</param>
        /// <example>
        ///     var db = new DataAccessSQLite("Data Source=mydata.db");
        /// </example>
        public DataAccessMySQL(IConfiguration config)
        {
            _connectionString = config.GetConnectionString("MySQL84");
        }

        /// <summary>
        ///     Get a multiple records
        /// </summary>
        /// <param name="sql">SQL select query</param>
        /// <param name="param">Parameters in query</param>
        /// <returns>A datatable</returns>
        /// <example>
        ///     string sql = "SELECT * FROM Contacts WHERE LastName = @lastname";
        ///     var param = new DynamicParametrs();
        ///     param.Add("@lastname", value: [value], dbType: DbType.String);
        ///     var result = await [this].GetRecords(sql, param).Result;
        ///     // Note: [value] is user defined, [this] is an instance of this class
        /// </example>
        public async Task<IEnumerable<dynamic>> GetRecordsAsync(string sql, DynamicParameters? param)
        {
            try
            {
                using (var conn = new MySqlConnection(_connectionString))
                {
                    var output = await conn.QueryAsync(sql, param);
                    return output;
                }
            }
            catch { throw; }
        }

        /// <summary>
        ///     Get one record
        /// </summary>
        /// <param name="sql">SQL select query</param>
        /// <param name="param">Parameters in query</param>
        /// <returns>A dynamic object</returns>
        /// <example>
        ///     string sql = "SELECT * FROM Contacts WHERE Id = @id";
        ///     var param = new DynamicParametrs();
        ///     param.Add("@id", value: [value], dbType: DbType.Int32);
        ///     var result = await [this].GetOneRecord(sql, param).Result;
        ///     
        ///     // Note: [value] is user defined, [this] is an instance of this class
        /// </example>
        public async Task<dynamic?> GetOneRecordAsync(string sql, DynamicParameters? param)
        {
            try
            {
                using (var conn = new MySqlConnection(_connectionString))
                {
                    var output = await conn.QueryFirstOrDefaultAsync(sql, param);
                    return output;
                }
            }
            catch { throw; }
        }

        /// <summary>
        ///     Perform, INSERT, UPDATE, or DELETE
        /// </summary>
        /// <param name="sql">SQL select query</param>
        /// <param name="param">Parameters in query</param>
        /// <example>
        ///     string sql = "INSERT INTO Contacts (FirstName, LastName) VALUES (@firstname, @lastname)";
        ///     // sql = "UPDATE Contacts SET FirstName = @firtname, LastName = @lastname WHERE Id = @id";
        ///     // sql = "DELETE FROM Contacts WHERE Id = @id";
        ///     
        ///     var param = new DynamicParametrs();
        ///     param.Add("@id", value: [value], dbType: DbType.Int32);
        ///     param.Add("@firstname", value: [value], dbType: DbType.String);
        ///     param.Add("@lastname", value: [value], dbType: DbType.String);
        ///     
        ///     var result = await [this].ExecuteNonQuery(sql, param);
        ///     
        ///     // Note: [value] is user defined, [this] is an instance of this class
        /// </example>
        public async Task ExecuteNonQueryAsync(string sql, DynamicParameters? param)
        {
            try
            {
                using (var conn = new MySqlConnection(_connectionString))
                {
                    await conn.ExecuteAsync(sql, param);
                }
            }
            catch { throw; }
        }
    }
}
