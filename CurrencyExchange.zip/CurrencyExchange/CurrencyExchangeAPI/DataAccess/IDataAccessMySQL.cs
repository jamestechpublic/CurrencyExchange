﻿using Dapper;

namespace CurrencyExchangeAPI.DataAccess
{
    public interface IDataAccessMySQL
    {
        Task<IEnumerable<dynamic>> GetRecordsAsync(string sql, DynamicParameters? param);
        Task<dynamic?> GetOneRecordAsync(string sql, DynamicParameters? param);
        Task ExecuteNonQueryAsync(string sql, DynamicParameters? param);
    }
}
