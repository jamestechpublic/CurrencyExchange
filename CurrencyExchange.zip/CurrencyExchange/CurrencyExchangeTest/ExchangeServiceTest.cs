using CurrencyExchangeAPI.DataAccess;
using CurrencyExchangeAPI.Models;
using CurrencyExchangeAPI.Services;
using FluentAssertions;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace CurrencyExchangeTest
{
    public class ExchangeServiceTest
    {
        private IDataAccessMySQL _db;
        private IDistributedCache _cache;

        public ExchangeServiceTest()
        {
            var config = new ConfigurationBuilder().AddJsonFile("appsettings.json", optional: false).Build();
            _db = new DataAccessMySQL(config);

            // setup Redis service...
            var services = new ServiceCollection();
            services.AddStackExchangeRedisCache(options => {
                options.Configuration = config.GetConnectionString("Redis");
                options.InstanceName = "Redis_";
            }); 
            var provider = services.BuildServiceProvider();
            _cache = provider.GetService<IDistributedCache>();
        }

        [Fact]
        public void GetHistoryAsync_ReturnsExchangeRatesFromDB()
        {
            // Arrange
            var obj = new ExchangeService(_db, _cache);

            // Act
            var result = obj.GetHistoryAsync();

            // Assert
            result.Result.Should().NotBeNull();
            result.Result.Should().BeOfType<List<ExchangeRate>>();
            result.Result.Should().HaveCountGreaterThan(0);
        }

        [Fact]
        public void CallPublicApiAsync_ReturnsExchangeRatesFromHttp()
        {
            // Arrange
            var obj = new ExchangeService(_db, _cache);

            // Act
            var result = obj.CallPublicApiAsync();

            // Assert
            result.Result.Should().NotBeNull();
            result.Result.Should().BeOfType<List<ExchangeRate>>();
            result.Result.Should().HaveCountGreaterThan(0);
        }

        [Fact]
        public async void ConvertCurrency_ReturnConvertedCurrency()
        {
            // Arrange
            var obj = new ExchangeService(_db, _cache);
            var rates = await obj.GetExchangeRatesAsync();
            string testBase = "USD";
            string testTarget = "ZAR";
            string testAmount = "100";

            decimal expectedAmount = 0m;
            foreach (var rate in rates)
            {
                if (rate.Currency == testTarget) expectedAmount = 100 * rate.Rate;
            }

            // Act
            var result = await obj.ConvertCurrencyAsync(testBase, testTarget, testAmount);
            var resultAmount = decimal.Parse(result);

            // Assert
            resultAmount.Should().Be(expectedAmount);
        }
    }
}