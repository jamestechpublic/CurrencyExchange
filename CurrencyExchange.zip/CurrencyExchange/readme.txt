[Please see README.md on https://github.com/jamestechpublic/CurrencyExchange.git]

CurrencyExchange
================
Currency Exchange Manager - Evaluation Project
by James Lombard (May 2024)
C# WebAPI & Test projects created in Visual Studio 2022
Note: Please review appsettings.json file connection strings.

Source Code File Structure
--------------------------
CurrencyExchange
	CurrencyExchangeAPI
	Controllers
	DataAccess
	Extensions
	Models
	Services
CurrencyExchangeTest
Screenshots

Require
-------
- A MySQL Database Scheme:
  exchangedb
	exchangerate
		Currency VARCHAR(3) PRIMARY NOT-NULL UNIQUE
		Rate DECIMAL(25,15) NOT-NULL
		LastUpdate VARCHAR(15) NOT-NULL
- A Redis cache, running in a Docker container at localhost:6379
- Currency Exchange Data is called from: https://api.freecurrencyapi.com/v1/latest?apikey=fca_live_8yCAXG0RLiGkyt3KaMGchoLscTgNbW4u7dk4dPTp

